package ru.bstu.iitus.vt41.gvo.construction;
import ru.bstu.iitus.vt41.gvo.service.InputData;
import java.util.Scanner;

// Путепроводное сооружение

public class OverpassConstruction extends Construction {
    @Override
    public Integer type() { return 5; }

    @Override
    public void init(Scanner scanner){
        System.out.println("Введите данные о путепроводном сооружение: ");
        InputData input = new InputData(scanner);
        input.inputString(""); // Пропуск лишнего символа с клавиатуры
        this.street = input.inputString("Улица: ");
        this.mainMaterial = input.inputString ("Основной материал: ");
        this.lifetime = input.inputInt("Cрок эксплуатации: ");
    }

    @Override
    public String toString(){
        return String.format("Путепроводное сооружение: ул. %s. Материал - %s. Срок эксплуатации - %d",
                this.street, this.mainMaterial, this.lifetime);
    }
}

