package ru.bstu.iitus.vt41.gvo.construction;

// Частный дом

import ru.bstu.iitus.vt41.gvo.service.InputData;

import java.util.Scanner;

public class PrivateHouse extends Building {
    int size;  // Размер участка.

    @Override
    public Integer type() { return 3; }

    @Override
    public void init(Scanner scanner){
        super.init(scanner);

        InputData input = new InputData(scanner);
        this.size = input.inputInt("Размер участка: ");
    }

    @Override
    public String toString() {
        return String.format("Частный дом! " + super.toString() + ", размер участка %d", this.size);
    }
}