package ru.bstu.iitus.vt41.gvo.service;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.InputMismatchException;
import java.util.Scanner;

public class InputData {

    Scanner scanner;

    public InputData(Scanner scanner) {
        this.scanner = scanner;
    }

    public String inputString(String msg) {
        System.out.print(msg);
        return scanner.nextLine();
    }

    public int inputInt(String msg) {
        System.out.print(msg);
        return scanner.nextInt();
    }

//    public int inputInteger(String msg) {
//        int     value = 0;
//        boolean flag  = true;
//        while (flag) {    // Либо рекурсия.
//            try {
//                System.out.println(msg);
//                value = scanner.nextInt(); // Ввод значения характериистики.
//                flag = false;
//            } catch (InputMismatchException ex) {
//                System.out.println("Данные введены неверно! Повторите ввод.");
//                scanner.nextLine();
//            }
//        }
//        scanner.nextLine();
//        return value;
//    }

//    public Calendar inputDate(String msg) {
//        System.out.println(msg);
//        int year  = inputInteger("Год:");
//        int month = inputInteger("Месяц:");
//        int day   = inputInteger("День:");
//        while (!dateIsValid(year, month, day)) {
//            System.out.println("Дата введена неверной! Повторите ввод.");
//            year = inputInteger("Год:");
//            month = inputInteger("Месяц:");
//            day = inputInteger("День:");
//        }
//        GregorianCalendar date = new GregorianCalendar(year, month, day);
//        return date;
//    }
//
//    private boolean dateIsValid(int y, int m, int d) {
//        try {
//            LocalDate ld = LocalDate.of(y, m, d);
//            return Boolean.TRUE;
//        } catch (DateTimeException ex) {
//            return Boolean.FALSE;
//        }
//    }
}
