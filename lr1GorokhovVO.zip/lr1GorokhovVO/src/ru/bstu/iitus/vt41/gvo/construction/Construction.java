package ru.bstu.iitus.vt41.gvo.construction;
import java.util.Scanner;

public abstract class Construction {
    String street;
    int lifetime;           // Cрок эксплуатации.
    String mainMaterial;    // Основной материал, из которого сделано сооружение.

    public abstract Integer type();             // Номер класса.

    public abstract void init(Scanner scanner); // Считывание параметров с консоли.

    public int getExploitationPeriod() { // Возвращает срок эксплуатации сооружения.
        return lifetime;
    }
}
