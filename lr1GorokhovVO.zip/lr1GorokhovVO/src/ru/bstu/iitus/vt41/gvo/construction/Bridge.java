package ru.bstu.iitus.vt41.gvo.construction;
import ru.bstu.iitus.vt41.gvo.service.InputData;
import java.util.Scanner;

// Мост

public class Bridge extends OverpassConstruction {
    int size; // Длина.

    @Override
    public Integer type() { return 6; }

    @Override
    public void init(Scanner scanner){
        super.init(scanner);

        InputData input = new InputData(scanner);
        this.size = input.inputInt("Длина: ");
    }

    @Override
    public String toString(){
        return String.format("Мост! " + super.toString() + ". Длина - %d", this.size);
    }

}