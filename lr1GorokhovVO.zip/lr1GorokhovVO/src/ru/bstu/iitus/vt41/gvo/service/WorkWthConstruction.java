package ru.bstu.iitus.vt41.gvo.service;
import ru.bstu.iitus.vt41.gvo.construction.Construction;
import ru.bstu.iitus.vt41.gvo.enums.TypeConstruction;
import ru.bstu.iitus.vt41.gvo.service.InputData;
import java.util.Scanner;
import java.util.*;

public class WorkWthConstruction {
    private static WorkWthConstruction instance = new WorkWthConstruction();

    Scanner scanner = new Scanner(System.in);
    private InputData inputData = new InputData(scanner);

    private WorkWthConstruction () {}

    public static WorkWthConstruction getInstance() {
        return instance;
    }

    public ArrayList<Construction> inputDatas() {   // 1
        System.out.print("Введите количество сооружений: ");
        int               count = scanner.nextInt();
        ArrayList<Construction> list  = new ArrayList<Construction>();

        for (int i = 0; i < count; i++) {
            list.add(InputData(scanner));
        }
        return list;
    }

    private Construction InputData(Scanner scanner) { // 2
        Construction construction;
        String labelInput = printConstructionTypeInformation();
        int mode = inputData.inputInt(labelInput + "\n"); // Вывод характеристик на экран и выбор конкретной
        boolean flag;

        do {
            construction = makeConstructionByIndex(scanner, mode);
            flag = construction == null;
        } while (flag);
        return construction;
    }

    private String printConstructionTypeInformation() { // 3 формирует строку со списком характеристик (студент ...)
        String labelInput = "\nУкажите тип вводимой записи:";
        for (TypeConstruction type : TypeConstruction.values()) {
            labelInput = labelInput + "\n" + type.getType() + ". " + type.getLabel();
        }
        return labelInput;
    }

    private Construction makeConstructionByIndex(Scanner scanner, int mode) { // 4
        TypeConstruction typeConstruction = TypeConstruction.valueOf(mode);
        System.out.println("Выбрано строение с типом '" + typeConstruction.getLabel() + "'");
        try {
            Construction currentConstruction = typeConstruction.getConstructionClass().newInstance();
            currentConstruction.init(scanner);            // Вызываем метод init нужного класса ---------------
            return currentConstruction;
        } catch (IllegalAccessException | InstantiationException e) {
          // e.printStackTrace();
            System.out.println("Введён неверный номер! Повторите ввод:  " + typeConstruction.getConstructionClass().getSimpleName());
            return null;
        }
    }

    public Construction getMin(List<Construction> construction) {
        Comparator<Construction> constructionComparator = Comparator.comparingInt(Construction::getExploitationPeriod);
        return Collections.min(construction, constructionComparator);
    }
}


