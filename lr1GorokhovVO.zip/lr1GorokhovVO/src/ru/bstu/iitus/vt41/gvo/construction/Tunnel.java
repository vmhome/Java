package ru.bstu.iitus.vt41.gvo.construction;
import ru.bstu.iitus.vt41.gvo.service.InputData;
import java.util.Scanner;

// Туннель

public class Tunnel extends OverpassConstruction {
    int size; // Протяженность
    @Override
    public Integer type() { return 7; }

    @Override
    public void init(Scanner scanner){
        super.init(scanner);

        InputData input = new InputData(scanner);
        this.size = input.inputInt("Протяженность: ");
    }

    @Override
    public String toString(){
        return String.format("Туннель! " + super.toString() + ". Протяженность - %d", this.size);
    }

}
