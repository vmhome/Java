package ru.bstu.iitus.vt41.gvo.enums;

import ru.bstu.iitus.vt41.gvo.construction.*;

public enum TypeConstruction {
    BUILDING(1, Building.class, "Здание"),
    SUPERMARKET(2, Supermarket.class, "Супермаркет"),
    PRIVATEHOUSE(3, PrivateHouse.class, "Частный дом"),
    APARTMENTHOUSE(4, ApartmentHouse.class, "Многоквартирный дом"),
    OVERPASSCONSTRUCTION(5, OverpassConstruction.class, "Путепроводное сооружение"),
    BRIDGE(6, Bridge.class, "Мост"),
    TUNNEL(7, Tunnel.class, "Туннель");

    Integer                 type;
    String                  label;
    Class<? extends Construction> constructionClass;

    TypeConstruction(int i, Class<? extends Construction> aClass, String label) {
        type = i;
        this.constructionClass = aClass;
        this.label = label;
    }

    public Integer getType() { return type; }

    public String getLabel() { return label; }

    public Class<? extends Construction> getConstructionClass() {
        return constructionClass;
    }

    public static TypeConstruction valueOf(Integer typeValue) {
        for (TypeConstruction typeConstruction : values()) {
            if (typeConstruction.getType().equals(typeValue)) {
                return typeConstruction;
            }
        }
        throw new IllegalArgumentException("введено не корректное значение");
    }
}
