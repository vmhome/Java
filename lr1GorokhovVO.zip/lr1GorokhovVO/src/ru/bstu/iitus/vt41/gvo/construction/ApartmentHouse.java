package ru.bstu.iitus.vt41.gvo.construction;
import ru.bstu.iitus.vt41.gvo.service.InputData;
import java.util.Scanner;

// Многоквартирный дом

public class ApartmentHouse extends Building {
    int apartments; // Кол-во квартир.
    int entrances;  // Количество подъездов.

    @Override
    public Integer type() {
        return 4;
    }

    @Override
    public void init(Scanner scanner){
        super.init(scanner);

        InputData input = new InputData(scanner);
        this.apartments = input.inputInt("Кол-во квартир: ");
        this.entrances = input.inputInt("Количество подъездов: ");
    }

    @Override
    public String toString(){
        return String.format("Многоквартирный дом! " + super.toString() + ", %d квартир, %d подъездов",
                this.apartments, this.entrances);
    }
}
