package ru.bstu.iitus.vt41.gvo;
import ru.bstu.iitus.vt41.gvo.construction.Construction;
import ru.bstu.iitus.vt41.gvo.service.WorkWthConstruction;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ArrayList<Construction> construction;
        construction = WorkWthConstruction.getInstance().inputDatas();

        System.out.println("\n\nВведённые записи:");
        for (Construction p : construction) System.out.println(p);


        System.out.println("\nСооружение с минимальным сроком эксплуатации: " + WorkWthConstruction.getInstance().getMin(construction));
    }
}
