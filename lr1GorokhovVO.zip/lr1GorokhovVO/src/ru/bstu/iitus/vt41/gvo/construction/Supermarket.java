package ru.bstu.iitus.vt41.gvo.construction;

import ru.bstu.iitus.vt41.gvo.service.InputData;

import java.util.Scanner;

public class Supermarket extends Building {
    String name; // Название супермаркета;

    @Override
    public Integer type() { return 2; }

    @Override
    public void init (Scanner scanner) {
        super.init(scanner);

        InputData input = new InputData(scanner);
        input.inputString(""); // Пропуск лишнего символа с клавиатуры
        this.name = input.inputString("Название супермаркета: ");
    }

    @Override
    public String toString() {
        return String.format("Супермаркет %s !" + super.toString(), this.name);
    }
}
