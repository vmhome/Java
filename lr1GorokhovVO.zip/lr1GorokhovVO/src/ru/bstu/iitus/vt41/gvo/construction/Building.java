package ru.bstu.iitus.vt41.gvo.construction;
import ru.bstu.iitus.vt41.gvo.service.InputData;
import java.util.Scanner;

// Здание

public class Building extends Construction {
    String number;  // Номер дома.

    @Override
    public Integer type () { return 1; }

    @Override
    public void init (Scanner scanner) {
        System.out.println("Введите информацию о здании:");
        InputData input = new InputData(scanner);
        input.inputString(""); // Пропуск лишнего символа с клавиатуры
        this.street = input.inputString("Улица: ");
        this.number = input.inputString("Номер дома: ");  // String т.к. может быть номер 169a, 169б
        this.mainMaterial = input.inputString ("Основной материал: ");
        this.lifetime = input.inputInt("Cрок эксплуатации: ");
    }

    @Override
    public String toString () {
        return String.format("Здание: %s %s. Материал - %s. Срок эксплуатации - %d",
                this.street, this.number, this.mainMaterial, this.getExploitationPeriod());
    }
}

